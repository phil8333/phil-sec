
/* PHILSEC v3 main.js — advanced */
document.documentElement.classList.add('page-enter');
window.addEventListener('load', ()=>{ setTimeout(()=>document.documentElement.classList.add('show'),30); });

// NAV TOGGLE
const navToggle = document.getElementById('navToggle');
const nav = document.querySelector('.ps-nav');
if(navToggle){
  navToggle.addEventListener('click', ()=>{ nav.classList.toggle('open'); navToggle.classList.toggle('open'); });
  document.addEventListener('click', (e)=>{ if(!nav.contains(e.target) && !navToggle.contains(e.target)){ nav.classList.remove('open'); navToggle.classList.remove('open'); }});
}

// THEME
const themeBtn = document.getElementById('themeBtn');
const html = document.documentElement;
const saved = localStorage.getItem('theme');
if(saved){ html.setAttribute('data-theme', saved); }
if(themeBtn){
  themeBtn.addEventListener('click', ()=>{
    const next = html.getAttribute('data-theme') === 'light' ? '' : 'light';
    if(next) html.setAttribute('data-theme','light'); else html.removeAttribute('data-theme');
    localStorage.setItem('theme', next || 'dark');
  });
}

// SCROLL REVEAL
const reveals = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries)=>{ entries.forEach(en=>{ if(en.isIntersecting){ en.target.classList.add('show'); io.unobserve(en.target); } }); }, {threshold:0.15});
reveals.forEach(r=>io.observe(r));

// LAZY LOAD IMAGES
const lazyImgs = document.querySelectorAll('img[data-src]');
const imgObserver = new IntersectionObserver((entries)=>{ entries.forEach(e=>{ if(e.isIntersecting){ const img=e.target; img.src=img.dataset.src; img.removeAttribute('data-src'); imgObserver.unobserve(img); } }); }, {rootMargin:'200px'});
lazyImgs.forEach(i=>imgObserver.observe(i));

// FETCH NEWS (from static JSON in /data/news.json)
async function loadNews(){
  try{
    const res = await fetch('/data/news.json');
    const data = await res.json();
    const grid = document.getElementById('newsGrid');
    if(grid && data.length){
      grid.innerHTML = data.map(item=>`
        <article class="card reveal">
          <div class="card-media" style="background-image:linear-gradient(135deg,#0ea5ff33,#6ee7b733)"></div>
          <h3 class="title">${item.title}</h3>
          <p class="excerpt">${item.excerpt}</p>
          <div class="meta">${item.time} • ${item.category}</div>
        </article>
      `).join('');
      // re-run reveal observer for new items
      document.querySelectorAll('.reveal').forEach(r=>io.observe(r));
    }
  }catch(err){ console.error('news load failed',err); }
}
loadNews();

// LOAD TOOLS (from /data/tools.json)
async function loadTools(){
  try{
    const res = await fetch('/data/tools.json');
    const data = await res.json();
    const grid = document.getElementById('toolsGrid');
    if(grid && data.length){
      grid.innerHTML = data.map(t=>`
        <article class="card reveal">
          <div class="card-media" style="background:linear-gradient(135deg,#7c4dff33,#2ea3ff33)"></div>
          <h3 class="title">${t.name}</h3>
          <p class="excerpt">${t.desc}</p>
          <div class="meta">Category: ${t.category} • ${t.latest}</div>
        </article>
      `).join('');
      document.querySelectorAll('.reveal').forEach(r=>io.observe(r));
    }
  }catch(err){ console.error('tools load failed',err); }
}
loadTools();

// DOWNLOADS: build downloads grid from files listed in assets/downloads
async function loadDownloads(){
  try{
    const res = await fetch('/data/downloads.json');
    const data = await res.json();
    const grid = document.getElementById('downloadsGrid');
    if(grid && data.length){
      grid.innerHTML = data.map(d=>`
        <article class="card reveal">
          <div class="card-media" style="background:linear-gradient(135deg,#2ea3ff33,#00eaff33)"></div>
          <h3 class="title">${d.title}</h3>
          <p class="excerpt">${d.desc}</p>
          <a class="btn btn-primary" href="${d.href}" download>Download</a>
          <div class="meta">${d.size}</div>
        </article>
      `).join('');
      document.querySelectorAll('.reveal').forEach(r=>io.observe(r));
    }
  }catch(err){ console.error('downloads load failed',err); }
}
loadDownloads();

// SCROLL TO TOP BUTTON
const topBtn = document.createElement('button');
topBtn.className='scroll-top-btn';
topBtn.textContent='↑';
document.body.appendChild(topBtn);
topBtn.addEventListener('click', ()=>window.scrollTo({top:0,behavior:'smooth'}));
window.addEventListener('scroll', ()=>{ if(window.scrollY>300) topBtn.classList.add('show'); else topBtn.classList.remove('show'); });
